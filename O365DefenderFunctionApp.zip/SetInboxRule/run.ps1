using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)
$flag = 0
# Write to the Azure Functions log stream.
Write-Host "Setting inbox rule status"

$Mailbox = $Request.Body.Mailbox
$Identity = $Request.Body.Identity
$Enabled = $Request.Body.Enabled
$DisableAll = $Request.Body.DisableAll
# Interact with query parameters or the body of the request.

try{
if($Mailbox -AND $DisableAll -eq $true)
{
    # Disable all inbox rules for the mailbox
    Write-Host "Disabling all inbox rules for mailbox: $Mailbox"
    $rules = Get-InboxRule -Mailbox "$Mailbox"
    $disabledCount = 0

    foreach($rule in $rules){
        Set-InboxRule -Mailbox "$Mailbox" -Identity $rule.Identity -Enabled $false
        if($?){
            Write-Host "Successfully disabled rule: $($rule.Name)"
            $disabledCount++
        }
    }

    $Result = "Successfully disabled $disabledCount inbox rule(s) for mailbox: $Mailbox"
    $flag = 1
}
elseif($Mailbox -AND $Identity -AND ($Enabled -eq $true -OR $Enabled -eq $false))
{
    # Set specific inbox rule enabled/disabled status
    $status = if($Enabled -eq $true){"enabled"}else{"disabled"}
    Write-Host "Setting inbox rule '$Identity' to $status for mailbox: $Mailbox"

    $Result = Set-InboxRule -Mailbox "$Mailbox" -Identity "$Identity" -Enabled $Enabled
    if($?){
        Write-Host "Successfully $status the rule"
        $Result = "Successfully $status inbox rule '$Identity' for mailbox: $Mailbox"
        $flag = 1
    }
    else
    {
        Write-Host "Failed to update inbox rule"
    }

}else{
    Write-Host "Missing required parameters. Provide: (Mailbox + Identity + Enabled) OR (Mailbox + DisableAll)"
}
}

catch{
    Write-Host "$_.Exception"
    $Result = "$_.Exception"
}

finally{
if($flag){
    # Associate values to output bindings by calling 'Push-OutputBinding'.
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = [HttpStatusCode]::OK
        Body = $Result
    })}else{

        Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
            StatusCode = [HttpStatusCode]::NotFound
            Body = $Result
        })
    }
}
