using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)
$flag = 0
# Write to the Azure Functions log stream.
Write-Host "Setting inbox rule status"

$Mailbox = $Request.Body.Mailbox
$Identity = $Request.Body.Identity
$Enabled = $Request.Body.Enabled
$DisableAll = $Request.Body.DisableAll
# Interact with query parameters or the body of the request.

try{
if($Mailbox -AND $DisableAll -eq $true)
{
    # Disable all inbox rules for the mailbox
    Write-Host "Disabling all inbox rules for mailbox: $Mailbox"
    $rules = Get-InboxRule -Mailbox "$Mailbox"
    $disabledCount = 0

    foreach($rule in $rules){
        Disable-InboxRule -Mailbox "$Mailbox" -Identity $rule.Identity -Confirm:$false
        if($?){
            Write-Host "Successfully disabled rule: $($rule.Name)"
            $disabledCount++
        }
    }

    $Result = "Successfully disabled $disabledCount inbox rule(s) for mailbox: $Mailbox"
    $flag = 1
}
elseif($Mailbox -AND $Identity -AND ($Enabled -eq $true -OR $Enabled -eq $false))
{
    # Set specific inbox rule enabled/disabled status
    if($Enabled -eq $false){
        Write-Host "Disabling inbox rule '$Identity' for mailbox: $Mailbox"
        Disable-InboxRule -Mailbox "$Mailbox" -Identity "$Identity" -Confirm:$false
        if($?){
            Write-Host "Successfully disabled the rule"
            $Result = "Successfully disabled inbox rule '$Identity' for mailbox: $Mailbox"
            $flag = 1
        }
    }
    else{
        Write-Host "Enabling inbox rule '$Identity' for mailbox: $Mailbox"
        Enable-InboxRule -Mailbox "$Mailbox" -Identity "$Identity" -Confirm:$false
        if($?){
            Write-Host "Successfully enabled the rule"
            $Result = "Successfully enabled inbox rule '$Identity' for mailbox: $Mailbox"
            $flag = 1
        }
    }

}else{
    Write-Host "Missing required parameters. Provide: (Mailbox + Identity + Enabled) OR (Mailbox + DisableAll)"
}
}

catch{
    Write-Host "$_.Exception"
    $Result = "$_.Exception"
}

finally{
if($flag){
    # Associate values to output bindings by calling 'Push-OutputBinding'.
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = [HttpStatusCode]::OK
        Body = $Result
    })}else{

        Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
            StatusCode = [HttpStatusCode]::NotFound
            Body = $Result
        })
    }
}
