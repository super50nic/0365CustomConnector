using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)
$flag = 0

# Write to the Azure Functions log stream.
Write-Host "Connecting to Exchange Online using Managed Identity..."

# Get organization name from request body or environment variable
$OrganizationName = $Request.Body.OrganizationName
if ([string]::IsNullOrEmpty($OrganizationName)) {
    $OrganizationName = $env:ORGANIZATION_NAME
    Write-Host "Using organization name from environment variable: $OrganizationName"
}

# Get optional User-Assigned Managed Identity Client ID from request
$ManagedIdentityAccountId = $Request.Body.ManagedIdentityAccountId

try {
    # Validate organization name is provided
    if ([string]::IsNullOrEmpty($OrganizationName)) {
        throw "OrganizationName is required. Provide it in the request body or set ORGANIZATION_NAME environment variable."
    }

    # Connect using Managed Identity
    # Runtime detection: If ManagedIdentityAccountId is provided, use User-Assigned MSI
    # Otherwise, use System-Assigned MSI
    if ([string]::IsNullOrEmpty($ManagedIdentityAccountId)) {
        Write-Host "Connecting with System-Assigned Managed Identity to organization: $OrganizationName"
        Connect-ExchangeOnline -ManagedIdentity -Organization $OrganizationName
    } else {
        Write-Host "Connecting with User-Assigned Managed Identity (ClientId: $ManagedIdentityAccountId) to organization: $OrganizationName"
        Connect-ExchangeOnline -ManagedIdentity -Organization $OrganizationName -ManagedIdentityAccountId $ManagedIdentityAccountId
    }

    if ($?) {
        $body = "Exchange Online connected successfully using Managed Identity"
        $flag = 1
        Write-Host $body
    }
}
catch {
    Write-Host "Connection failed: $_"
    $body = "Failed to connect to Exchange Online: $_"
}
finally {
    if ($flag) {
        # Associate values to output bindings by calling 'Push-OutputBinding'.
        Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
            StatusCode = [HttpStatusCode]::OK
            Body = $body
        })
    } else {
        Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
            StatusCode = [HttpStatusCode]::BadRequest
            Body = $body
        })
    }
}
